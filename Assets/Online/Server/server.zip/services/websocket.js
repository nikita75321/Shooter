const WebSocket = require('ws');
const { v4: uuidv4 } = require('uuid');
const {handleBinaryMessage,sendError,formatDateTime} = require('../utils');
const isPm2Master = process.env.NODE_APP_INSTANCE === '0';

const playerController = require('./playerController');
const clanController = require('./clanController');

//Достаем из скрипта констант нужные нам 
const {
    wsKey,
    //константы дальше
} = require ('../config/constants');

//Инициализация сокета
function setupWebSocketServer(server) {
    const wss = new WebSocket.Server({
        noServer: true 
    });
    
    let isInitialized = false;
    const initPromise = (async () => {
        await clearRedisData();
        isInitialized = true;
        console.log('WebSocket server initialization complete');
    })();
    
    server.on('upgrade', async (request, socket, head) => {
        try {
            if (!isInitialized) {
                console.log('Waiting for initialization...');
                await initPromise;
            }
            
            if (socket.wsHandled) {
                socket.destroy();
                return;
            }
            socket.wsHandled = true;
            
            wss.handleUpgrade(request, socket, head, (ws) => {
                wss.emit('connection', ws, request);
            });
        } catch (err) {
            console.error('Upgrade error:', err);
            socket.destroy();
        }
    });
    
    wss.on('connection', (ws) => {
        ws.id = uuidv4();// Добавляем уникальный ID
        console.log('New connection in Socket, total clients:', wss.clients.size);
        
        (async () => {
            try {
                await global.redisClient.set(`${wsKey}${ws.id}`, 'pending');
                
            } catch (error) {
                console.error('Redis set error:', error);
            }
        })();
        
        ws.isAlive = true;
        
        ws.on('pong', () => {
            ws.isAlive = true;
        });
        
        ws.send(JSON.stringify({
            action: 'server_time_response',
            server_time: formatDateTime(new Date())
        }));

        ws.on('error', (error) => {
            console.error('WebSocket error:', error);
            sendError(ws, 'WebSocket error occurred');
        });

        ws.on('message', async (message,isBinary) => {
            let data;

            if (isBinary) {
                data = handleBinaryMessage(ws, message);
            }
            else {
                data = JSON.parse(message);
            }

            if (!data) throw new Error('Invalid message format');
            
            //Вызвать нужную функцию в зависимости от полученного экшена
            switch (data.action) {
                //case 'get_server_stats': await PlayerController.handleCheckPlayer(ws, data); break; ПРИМЕР ОБРАБОТКИ ПРИШЕДШЕГО ЗАПРОСА 
                case 'ping':
                    // Ответ на ping
                    ws.send(JSON.stringify({
                        action: 'pong',
                        timestamp: data.timestamp // Возвращаем тот же timestamp для расчета задержки
                    }));
                    break;
                case 'demo_request': 
                await systemController.handleDemoRequest(ws, data); 
                break;
            case 'get_time_until_month_end': 
                await systemController.handleGetTimeUntilMonthEnd(ws); 
                break;
            case 'get_game_modes_status': 
                await systemController.handleGetGameModesStatus(ws); 
                break;

            // Level actions
            case 'save_level_json': 
                await levelController.handleSaveLevelJson(ws, data); 
                break;
            case 'get_level_json': 
                await levelController.handleGetLevelJson(ws, data); 
                break;
            case 'show_random': 
                await levelController.handleShowRandom(ws); 
                break;
            case 'show_top_plays': 
                await levelController.handleShowTopPlays(ws); 
                break;
            case 'show_top_rate': 
                await levelController.handleShowTopRate(ws); 
                break;
            case 'show_newest': 
                await levelController.handleShowNewest(ws); 
                break;
            case 'create_map': 
                await levelController.handleCreateMap(ws, data); 
                break;
            case 'search_levels': 
                await levelController.handleSearchLevels(ws, data); 
                break;
            case 'find_by_name': 
                await levelController.handleFindByName(ws, data); 
                break;
            case 'find_by_author': 
                await levelController.handleFindByAuthor(ws, data); 
                break;
            case 'increment_plays': 
                await levelController.handleIncrementPlays(ws, data); 
                break;
            case 'has_rating': 
                await levelController.handleHasRating(ws, data); 
                break;
            case 'rate_level': 
                await levelController.handleRateLevel(ws, data); 
                break;
            case 'create_name': 
                await levelController.handleCreateName(ws, data); 
                break;
            case 'check_user_exists': 
                await levelController.handleCheckUserExists(ws, data); 
                break;
            case 'check_level_exists': 
                await levelController.handleCheckLevelExists(ws, data); 
                break;
            case 'update_image_link': 
                await levelController.handleUpdateImageLink(ws, data); 
                break;
            case 'upload_screenshot': 
                await screenshotController.handleUploadScreenshot(ws, data); 
                break;

            // Player actions
            case 'register_player': 
                await playerController.handleRegisterPlayer(ws, data); 
                break;
            case 'player_connect': 
                await playerController.handlePlayerConnect(ws, data); 
                break;
            case 'update_player_rating': 
                await playerController.handleUpdatePlayerRating(ws, data); 
                break;
            case 'check_name': 
                await playerController.handleCheckName(ws, data); 
                break;
            case 'update_name': 
                await playerController.handleUpdatePlayerName(ws, data); 
                break;
            case 'update_rating': 
                await playerController.handleUpdateRating(ws, data); 
                break;
            case 'get_player_info': 
                await playerController.handleGetPlayerInfo(ws, data); 
                break;
            case 'get_player_data': 
                await playerController.handleGetPlayerData(ws, data); 
                break;

            // Clan actions
            case 'create_clan': 
                await clanController.handleCreateClan(ws, data); 
                break;
            case 'join_clan': 
                await clanController.handleJoinClan(ws, data); 
                break;
            case 'leave_clan': 
                await clanController.handleLeaveClan(ws, data); 
                break;
            case 'get_all_clans': 
                await clanController.handleGetAllClans(ws); 
                break;
            case 'search_clans': 
                await clanController.handleSearchClans(ws, data); 
                break;
            case 'get_clan_info': 
                await clanController.handleGetClanInfo(ws, data); 
                break;
            case 'get_clan_top_with_current': 
                await clanController.handleGetClanInfoWithTop(ws, data); 
                break;

            // Stats actions
            case 'update_player_stats': 
                await statsController.handleUpdatePlayerStats(ws, data); 
                break;
            case 'get_rating_leaderboard': 
                await statsController.handleGetRatingLeaderboard(ws, data); 
                break;
            case 'get_kills_leaderboard': 
                await statsController.handleGetKillsLeaderboard(ws, data); 
                break;

            // Hero actions
            case 'update_hero_stats': 
                await heroController.handleUpdateHeroStats(ws, data); 
                break;
            case 'update_favorite_hero': 
                await heroController.handleUpdateFavoriteHero(ws, data); 
                break;
            case 'get_hero_levels': 
                await heroController.handleGetHeroLevels(ws, data); 
                break;
            case 'update_hero_levels': 
                await heroController.handleUpdateHeroLevels(ws, data); 
                break;

            // Currency actions
            case 'claim_rewards': 
                await currencyController.handleClaimRewards(ws, data); 
                break;
            case 'add_currency': 
                await currencyController.handleAddCurrency(ws, data); 
                break;
            case 'spend_hero_cards': 
                await currencyController.handleSpendHeroCards(ws, data); 
                break;

                default:
                    sendError(ws, `Unknown action: ${data.action}`);
            }
        });

        ws.on('close', () => {
            //ЧТО СДЕЛАТЬ НА ОТКЛЮЧЕНИЕ СЕРВЕРА?
        });
    });
    
    const interval = setInterval(() => {
        wss.clients.forEach((ws) => {
            if (!ws.isAlive) {
                if(ws.id){
                    //ЧТО СДЕЛАТЬ НА ОТКЛЮЧЕНИЕ СЕРВЕРА?
                }
                return ws.terminate();
            }
            ws.isAlive = false;
            ws.ping();
        });
    }, 30000);

    wss.on('close', () => {
        console.log('Server closed');
        clearInterval(interval);
    });
    
    scheduleDailyRestart(wss); //перезагрузка сервера ночью
    return wss;
}

//чистка ключей, которые не нужно сохранять в БД
async function clearRedisData() {
    const patterns = [
        'connection:*',
        //'playerInGame:*'
    ];
    
    console.log('Completely flushed Redis database');
    
    for (const pattern of patterns) {
        const keys = await global.redisClient.keys(pattern);
        if (keys.length > 0) {
            await global.redisClient.del(keys);
            console.log(`Deleted ${keys.length} keys for ${pattern}`);
        }
    }
}

// Функция для отправки системного сообщения
async function sendRestartNotification(wss, message) {
    if (isPm2Master) {
        await ChatController.broadcastSystemMessage(null, {
            action: 'system_chat_message',
            message: `Server will restart <color=red>${message}</color>`,
            isSystem: true
        });
    }
}

// Функция для планирования перезагрузки
function scheduleDailyRestart(wss) {
    const now = new Date();
    const restartTime = new Date(
        now.getFullYear(),
        now.getMonth(),
        now.getDate(),
        0, 0, 0, 0
    );

    // Если время уже прошло сегодня, планируем на завтра
    if (now > restartTime) {
        restartTime.setDate(restartTime.getDate() + 1);
    }

    const timeUntilRestart = restartTime.getTime() - now.getTime();

    // Таймер для основного перезапуска
    setTimeout(() => {
        performRestartSequence(wss);
    }, timeUntilRestart);

    // Таймеры для предупреждений
    scheduleWarning(wss, timeUntilRestart - 60 * 60 * 1000, "in 1 hour");
    scheduleWarning(wss, timeUntilRestart - 30 * 60 * 1000, "in 30 minutes");
    scheduleWarning(wss, timeUntilRestart - 15 * 60 * 1000, "in 15 minutes");
    scheduleWarning(wss, timeUntilRestart - 5 * 60 * 1000, "in 5 minutes");
}

// Функция для планирования предупреждений
function scheduleWarning(wss, timeUntilWarning, message) {
    if (timeUntilWarning <= 0) return;

    setTimeout(() => {
        sendRestartNotification(wss, message);
    }, timeUntilWarning);
}

// Функция для выполнения последовательности перезагрузки
async function performRestartSequence(wss) {
    // Отправляем предупреждения с обратным отсчетом
    await sendRestartNotification(wss, "in 3 minutes");
    await new Promise(resolve => setTimeout(resolve, 60 * 1000));
    await sendRestartNotification(wss, "in 2 minutes");
    await new Promise(resolve => setTimeout(resolve, 60 * 1000));
    await sendRestartNotification(wss, "in 1 minute");
    await new Promise(resolve => setTimeout(resolve, 50 * 1000));

    // Последние 10 секунд - секундный отсчет
    for (let i = 10; i > 0; i--) {
        await sendRestartNotification(wss, `in ${i} seconds`);
        await new Promise(resolve => setTimeout(resolve, 1000));
    }

    // Отправляем уведомление о перезагрузке всем клиентам
    wss.clients.forEach(client => {
        if (client.readyState === WebSocket.OPEN) {
            client.send(JSON.stringify({
                action: 'call',
                message: 'server_restart'
            }));
            setTimeout(() => {
                client.close(1001, 'Server restarting'); // 1001 = "going away"
            }, 3000); // 5 секунд на завершение
        }
    });
    
    // Даём время на закрытие соединений
    setTimeout(() => {
        wss.close(() => {
            console.log('Сервер корректно остановлен');
            process.exit(0);
        });
    }, 2000); // 5 секунд на завершение
}

module.exports = {
    setupWebSocketServer,
};