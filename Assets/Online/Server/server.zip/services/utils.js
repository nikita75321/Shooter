const WebSocket = require('ws');
const {wsKey} = require("../config/constants");
function sendError(ws, message) {
    if (ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({
            action: 'error',
            message: message || 'Internal server error'
        }));
    }
}

function handleBinaryMessage(ws, binaryData) {
    try {
        const buffer = Buffer.from(binaryData);
        let offset = 0;

        const actionLength = buffer.readUInt8(offset);
        offset += 1;

        const action = buffer.toString('utf8', offset, offset + actionLength);
        offset += actionLength;

        const jsonData = buffer.toString('utf8', offset);
        const data = JSON.parse(jsonData);
        data.action = action;

        return data;
    } catch (error) {
        console.error('Error processing binary message:', error);
        sendError(ws, 'Failed to process binary message');
        return null;
    }
}

function formatDateTime(date) {
    const d = new Date(date);
    const day = String(d.getDate()).padStart(2, '0');
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const year = d.getFullYear();
    const hours = String(d.getHours()).padStart(2, '0');
    const minutes = String(d.getMinutes()).padStart(2, '0');
    const seconds = String(d.getSeconds()).padStart(2, '0');

    return `${day}.${month}.${year} ${hours}:${minutes}:${seconds}`;
}
async function deleteKeysByPattern(pattern) {
    let cursor = '0';
    let totalDeleted = 0;

    console.log(`Starting deletion for pattern: ${pattern}`);

    do {
        const reply = await global.redisClient.scan(cursor, {
            MATCH: pattern,
            COUNT: 1000
        });

        cursor = reply.cursor;
        const keys = reply.keys;

        if (keys.length > 0) {
            console.log(`Found ${keys.length} keys to delete for pattern: ${pattern}`);
            const deletedCount = await global.redisClient.del(keys);
            totalDeleted += deletedCount;
            console.log(`Deleted ${deletedCount} keys (pattern: ${pattern})`);
        }
    } while (cursor !== '0');

    console.log(`Total deleted for pattern ${pattern}: ${totalDeleted}`);
    return totalDeleted;
}

async function acquireLock(lockKey, ttl) {
    return await global.redisClient.set(lockKey, 'LOCKED', 'NX', 'PX', ttl);
}

async function releaseLock(lockKey) {
    await global.redisClient.del(lockKey);
}

/**
 * Подсчитывает количество ключей в Redis, соответствующих шаблону, используя SCAN
 * @param {string} pattern - Шаблон ключа (например, "prefix:*")
 * @returns {Promise<number>} - Количество найденных ключей
 */
async function countKeysByPattern(pattern) {
    const CACHE_TTL = 30; // 30 секунд
    const cacheKey = `count_cache:${pattern.replace(/\*/g, '_')}`; // Заменяем * для безопасности ключа

    // Пытаемся получить данные из кеша
    try {
        const cachedResult = await global.redisClient.get(cacheKey);
        if (cachedResult !== null) {
            return parseInt(cachedResult, 10);
        }
    } catch (cacheError) {
        console.error('Cache read error:', cacheError);
    }

    if (!global?.redisClient?.scan) {
        console.error('Redis client is not available or scan method missing');
        return 0;
    }

    let count = 0;
    let cursor = '0';
    let iteration = 0;
    const maxIterations = 1000;

    try {
        do {
            const reply = await Promise.race([
                global.redisClient.scan(cursor, {
                    MATCH: pattern,
                    COUNT: 500
                }),
                new Promise((_, reject) =>
                    setTimeout(() => reject(new Error('Redis SCAN timeout')), 5000)
                )
            ]);

            let keys = [];
            if (reply && typeof reply === 'object' && !Array.isArray(reply)) {
                cursor = reply.cursor;
                keys = reply.keys || [];
            } else if (Array.isArray(reply) && reply.length >= 2) {
                cursor = reply[0];
                keys = reply[1] || [];
            } else {
                console.error('Invalid SCAN reply format:', reply);
                break;
            }

            count += keys.length;
            iteration++;

            if (iteration > maxIterations) {
                console.error('SCAN iterations limit exceeded');
                break;
            }

        } while (cursor !== '0');
        
        // Сохраняем результат в кеш с TTL
        try {
            await global.redisClient.setEx(cacheKey, CACHE_TTL, count.toString());
        } catch (cacheError) {
            console.error('Cache write error:', cacheError);
        }

        return count;
    } catch (error) {
        console.error(`Redis SCAN error for pattern "${pattern}":`, error);
        return 0;
    }
}

module.exports = {
    sendError,
    formatDateTime,
    handleBinaryMessage,
    deleteKeysByPattern,
    releaseLock,
    acquireLock,
    countKeysByPattern
};