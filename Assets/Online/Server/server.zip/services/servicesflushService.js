const { db } = require('../config/db');

//ЗАГНАТЬ ЭТО В СИКУ И ПЕРЕПИСАТЬ ПОД СВОИ СОХРЫ
async function flushPlayerData(playerId) {
    const rawProfile = await global.redisClient.get(`player:${playerId}:profile`);
    if (!rawProfile) {
        console.log(`[${playerId}] No profile data in Redis, skipping flush`);
        return;
    }

    const profile = JSON.parse(rawProfile);
    const inapps = profile.in_apps || {};
    const startTime = Date.now();

    try {
        await db.transaction(async (client) => {
            // 1. Проверяем и обновляем/создаем игрока
            await handlePlayerData(client, playerId, profile);

            // 2. Обновляем in_apps
            await handleInApps(client, playerId, inapps);

            // 3. Обновляем инвентарь
            await handleInventory(client, playerId);

            // 4. Обновляем ферму
            await handleFarm(client, playerId);

            // 5. Обновляем скины
            await handleSkins(client, playerId);

            // 6. Обновляем события
            await handleEvents(client, playerId);
        });

        const duration = Date.now() - startTime;
        console.log(`[${playerId}] Data successfully flushed in ${duration}ms`);
    } catch (err) {
        console.error(`[${playerId}] Flush failed:`, err);
        throw err;
    }
}

// Вспомогательные функции для каждой операции

async function handlePlayerData(client, playerId, profile) {
    const playerExists = await client.query(
        'SELECT 1 FROM players WHERE player_id = $1',
        [playerId]
    );

    if (playerExists.rows.length > 0) {
        await client.query(`
            UPDATE players 
            SET username = $1,
                money = $2,
                income_for_all_time = $3,
                tutor_point = $4,
                in_app_count = $5,
                last_online = NOW()
            WHERE player_id = $6
        `, [
            profile.username,
            profile.money,
            profile.income_for_all_time,
            profile.tutor_point,
            profile.in_app_count,
            playerId
        ]);
    } else {
        await client.query(`
            INSERT INTO players(
                player_id, 
                username, 
                money, 
                income_for_all_time, 
                tutor_point, 
                in_app_count, 
                platform, 
                last_online,
                change_name_count
            )
            VALUES($1, $2, $3, $4, $5, $6, $7, NOW(), $8)
        `, [
            playerId,
            profile.username,
            profile.money,
            profile.income_for_all_time || 0,
            profile.tutor_point,
            profile.in_app_count,
            profile.platform || 'unknown',
            profile.change_name_count || 2
        ]);
    }
}

async function handleInApps(client, playerId, inapps) {
    await client.query(`
        INSERT INTO in_apps(
            player_id,
            vip_festival,
            the_king,
            upgrade_store,
            sale_x2,
            grow_x2,
            stock_x2
        )
        VALUES($1, $2, $3, $4, $5, $6, $7)
        ON CONFLICT (player_id) DO UPDATE SET
            vip_festival = EXCLUDED.vip_festival,
            the_king = EXCLUDED.the_king,
            upgrade_store = EXCLUDED.upgrade_store,
            sale_x2 = EXCLUDED.sale_x2,
            grow_x2 = EXCLUDED.grow_x2,
            stock_x2 = EXCLUDED.stock_x2
    `, [
        playerId,
        inapps.vip_festival || false,
        inapps.the_king || false,
        inapps.upgrade_store || false,
        inapps.sale_x2 || false,
        inapps.grow_x2 || false,
        inapps.stock_x2 || false
    ]);
}

async function handleInventory(client, playerId) {
    const rawInventory = await global.redisClient.get(`inventory:${playerId}`);
    if (rawInventory) {
        await client.query(`
            INSERT INTO player_inventory(player_id, inventory_data) 
            VALUES($1, $2::jsonb)
            ON CONFLICT (player_id) DO UPDATE SET 
                inventory_data = EXCLUDED.inventory_data,
                last_updated = NOW()
        `, [playerId, rawInventory]);
    }
}

async function handleFarm(client, playerId) {
    const rawFarm = await global.redisClient.get(`farm:${playerId}`);
    if (rawFarm) {
        try {
            const parsedData = JSON.parse(rawFarm);
            const farm_data = parsedData.farm_data;
            const likes = parsedData.likes || 0; // Default to 0 if not provided

            // Validate farm_data exists and is not null
            if (!farm_data) {
                console.error("Invalid farm_data for player:", playerId);
                return;
            }

            await client.query(`
                INSERT INTO player_farms(player_id, farm_data, likes)
                VALUES($1, $2::jsonb, $3)
                    ON CONFLICT (player_id) DO UPDATE SET
                    farm_data = EXCLUDED.farm_data,
                                                   likes = EXCLUDED.likes,
                                                   last_updated = NOW()
            `, [playerId, farm_data, likes]);
        } catch (error) {
            console.error("Error saving farm data:", {
                error: error.message,
                rawFarm: rawFarm,
                playerId: playerId
            });
            throw error;
        }
    }
}

async function handleSkins(client, playerId) {
    const rawSkins = await global.redisClient.get(`skins:${playerId}`);
    if (rawSkins) {
        const skins = JSON.parse(rawSkins);
        await client.query(`
            INSERT INTO player_skins(
                player_id,
                purchased_hat,
                purchased_cloath,
                purchased_accessories
            )
            VALUES($1, $2, $3, $4)
            ON CONFLICT (player_id) DO UPDATE SET
                purchased_hat = EXCLUDED.purchased_hat,
                purchased_cloath = EXCLUDED.purchased_cloath,
                purchased_accessories = EXCLUDED.purchased_accessories
        `, [
            playerId,
            skins.hats || '',
            skins.clothes || '',
            skins.accessories || ''
        ]);
    }
}

async function handleEvents(client, playerId) {
    const rawEvents = await global.redisClient.get(`events:${playerId}`);
    if (rawEvents) {
        const events = JSON.parse(rawEvents);
        const eventColumns = Object.keys(events);

        if (eventColumns.length > 0) {
            const setClauses = eventColumns.map(col => `${col} = ${col} + $${eventColumns.indexOf(col) + 2}`);

            await client.query(`
                INSERT INTO events (player_id, ${eventColumns.join(', ')})
                VALUES ($1, ${eventColumns.map((_, i) => `$${i + 2}`).join(', ')})
                ON CONFLICT (player_id) DO UPDATE SET
                    ${setClauses.join(', ')}
            `, [playerId, ...eventColumns.map(col => events[col])]);

            await global.redisClient.sAdd('active_events', eventColumns);
        }
    }
}

module.exports = { flushPlayerData };