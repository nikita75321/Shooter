//Константы, которые нужно будет применять в других скриптах
const Constants = {
    wsKey: `ws:connection:`, 
    myVar: 'Hello!'
};

module.exports = Constants;
