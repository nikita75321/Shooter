const { shooterPool } = require('../config/db');

async function handleUpdatePlayerStats(ws, data) {
    const requiredFields = ['player_id'];
    if (!isValidMessage(data, requiredFields)) {
        return sendError(ws, 'Missing required field: player_id');
    }

    const client = await shooterPool.connect();
    try {
        await client.query('BEGIN');

        const playerRes = await client.query(
            `SELECT 
                id,
                rating,
                money,
                donat_money,
                max_damage,
                best_rating,
                clan_name,
                clan_points
             FROM players 
             WHERE player_id = $1 
             FOR UPDATE`,
            [data.player_id]
        );

        if (playerRes.rows.length === 0) {
            throw new Error('Player not found');
        }

        const current = playerRes.rows[0];
        const newRating = (current.rating || 0) + (data.rating_change || 0);
        const newMaxDamage = Math.max(current.max_damage || 0, data.damage_dealt || 0);
        const winIncrement = data.is_win ? 1 : 0;

        const baseParams = [
            newRating,
            data.money_change || 0,
            data.donat_money_change || 0,
            data.kills || 0,
            winIncrement,
            data.revives || 0,
            newMaxDamage,
            data.shots_fired || 0,
            data.player_id
        ];

        let updateQuery = `
            UPDATE players SET
                rating = $1,
                best_rating = GREATEST(best_rating, $1),
                money = money + $2,
                donat_money = donat_money + $3,
                overral_kill = overral_kill + $4,
                match_count = match_count + 1,
                win_count = win_count + $5,
                revive_count = revive_count + $6,
                max_damage = $7,
                shoot_count = shoot_count + $8
        `;

        if (data.favorite_hero) {
            updateQuery += `, love_hero = $${baseParams.length + 1}`;
            baseParams.push(data.favorite_hero);
        }

        let clanId = null;
        if (data.clan_points_change && current.clan_name) {
            updateQuery += `, clan_points = $${baseParams.length + 1}`;
            baseParams.push(data.clan_points_change);

            const clanRes = await client.query(
                'SELECT clan_id FROM clans WHERE clan_name = $1 FOR UPDATE',
                [current.clan_name]
            );
            
            if (clanRes.rows.length > 0) {
                clanId = clanRes.rows[0].clan_id;
                await client.query(
                    'UPDATE clans SET clan_points = $1 WHERE clan_id = $2',
                    [data.clan_points_change, clanId]
                );
            }
        }

        updateQuery += ` WHERE player_id = $9 RETURNING *`;

        const updateRes = await client.query(updateQuery, baseParams);

        await client.query('COMMIT');

        const updated = updateRes.rows[0];
        const response = {
            action: 'player_stats_updated',
            stats: {
                rating: updated.rating,
                best_rating: updated.best_rating,
                money: updated.money,
                donat_money: updated.donat_money,
                overral_kill: updated.overral_kill,
                match_count: updated.match_count,
                win_count: updated.win_count,
                revive_count: updated.revive_count,
                max_damage: updated.max_damage,
                shoot_count: updated.shoot_count,
                love_hero: updated.love_hero || null,
                clan_points: updated.clan_points || 0
            }
        };

        if (clanId) {
            response.clan_id = clanId;
        }

        ws.send(JSON.stringify(response));

    } catch (error) {
        await client.query('ROLLBACK');
        console.error('Update player stats error:', error);
        sendError(ws, error.message.includes('love_hero') ? 
            'Invalid favorite hero data' : error.message);
    } finally {
        client.release();
    }
}
async function handleGetRatingLeaderboard(ws, data) {
    if (!isValidMessage(data, ['player_id'])) {
        return sendError(ws, 'Missing player_id');
    }

    const client = await shooterPool.connect();
    try {
        // 1. Get top 10 players by rating (with unique places)
        const topPlayers = await client.query(`
            WITH ranked_players AS (
                SELECT 
                    player_id,
                    player_name as name,
                    rating as value,
                    DENSE_RANK() OVER (ORDER BY rating DESC) as dense_rank,
                    ROW_NUMBER() OVER (ORDER BY rating DESC, id ASC) as unique_place
                FROM players
            )
            SELECT 
                player_id,
                name,
                value,
                unique_place as place
            FROM ranked_players
            ORDER BY unique_place
            LIMIT 10
        `);

        // 2. Get current player's position
        const myStats = await client.query(`
            WITH ranked_players AS (
                SELECT 
                    player_id,
                    player_name as name,
                    rating as value,
                    DENSE_RANK() OVER (ORDER BY rating DESC) as dense_rank,
                    ROW_NUMBER() OVER (ORDER BY rating DESC, id ASC) as unique_place
                FROM players
            )
            SELECT 
                name,
                value,
                unique_place as place
            FROM ranked_players
            WHERE player_id = $1
        `, [data.player_id]);

        ws.send(JSON.stringify({
            action: 'rating_leaderboard_response',
            top_players: topPlayers.rows,
            my_stats: myStats.rows[0] || null
        }));

    } catch (error) {
        console.error('Error in handleGetRatingLeaderboard:', error);
        sendError(ws, 'Failed to get rating leaderboard');
    } finally {
        client.release();
    }
}
async function handleGetKillsLeaderboard(ws, data) {
    if (!isValidMessage(data, ['player_id'])) {
        return sendError(ws, 'Missing player_id');
    }

    const client = await shooterPool.connect();
    try {
        // 1. Get top 10 players by kills (with unique places)
        const topPlayers = await client.query(`
            WITH ranked_players AS (
                SELECT 
                    player_id,
                    player_name as name,
                    overral_kill as value,
                    DENSE_RANK() OVER (ORDER BY overral_kill DESC) as dense_rank,
                    ROW_NUMBER() OVER (ORDER BY overral_kill DESC, id ASC) as unique_place
                FROM players
            )
            SELECT 
                player_id,
                name,
                value,
                unique_place as place
            FROM ranked_players
            ORDER BY unique_place
            LIMIT 10
        `);

        // 2. Get current player's position
        const myStats = await client.query(`
            WITH ranked_players AS (
                SELECT 
                    player_id,
                    player_name as name,
                    overral_kill as value,
                    DENSE_RANK() OVER (ORDER BY overral_kill DESC) as dense_rank,
                    ROW_NUMBER() OVER (ORDER BY overral_kill DESC, id ASC) as unique_place
                FROM players
            )
            SELECT 
                name,
                value,
                unique_place as place
            FROM ranked_players
            WHERE player_id = $1
        `, [data.player_id]);

        ws.send(JSON.stringify({
            action: 'kills_leaderboard_response',
            top_players: topPlayers.rows,
            my_stats: myStats.rows[0] || null
        }));

    } catch (error) {
        console.error('Error in handleGetKillsLeaderboard:', error);
        sendError(ws, 'Failed to get kills leaderboard');
    } finally {
        client.release();
    }
}

module.exports = {
    handleUpdatePlayerStats,
    handleGetRatingLeaderboard,
    handleGetKillsLeaderboard
};