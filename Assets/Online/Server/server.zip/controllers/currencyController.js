import { shooterPool } from '../config/db';

async function handleClaimRewards(ws, data) {
    const requiredFields = ['player_id', 'money', 'donat_money', 'hero_cards', 'open_characters'];
    if (!isValidMessage(data, requiredFields)) {
        return sendError(ws, 'Missing required fields');
    }

    const client = await shooterPool.connect();
    try {
        await client.query('BEGIN');

        await client.query(
            `UPDATE players SET 
                money = money + $1,
                donat_money = donat_money + $2
             WHERE player_id = $3`,
            [data.money, data.donat_money, data.player_id]
        );

        const heroCards = data.hero_cards;
        for (const [heroName, count] of Object.entries(heroCards)) {
            await client.query(
                `UPDATE players 
                 SET hero_card = jsonb_set(
                     COALESCE(hero_card, '{}'::jsonb),
                     $1,
                     to_jsonb(COALESCE((hero_card->>$2)::int, 0) + $3)
                 )
                 WHERE player_id = $4`,
                [`{${heroName}}`, heroName, count, data.player_id]
            );
        }

        const openCharacters = data.open_characters;
        if (openCharacters && Object.keys(openCharacters).length > 0) {
            await client.query(
                `UPDATE players 
                 SET open_characters = 
                     COALESCE(open_characters, '{}'::jsonb) || $1::jsonb
                 WHERE player_id = $2`,
                [JSON.stringify(openCharacters), data.player_id]
            );
        }

        await client.query('COMMIT');

        const result = await client.query(
            `SELECT money, donat_money, hero_card, open_characters 
             FROM players 
             WHERE player_id = $1`,
            [data.player_id]
        );

        ws.send(JSON.stringify({
            action: 'claim_rewards_response',
            success: true,
            money: result.rows[0].money,
            donat_money: result.rows[0].donat_money,
            hero_cards: result.rows[0].hero_card,
            open_characters: result.rows[0].open_characters
        }));

    } catch (error) {
        await client.query('ROLLBACK');
        console.error('Claim rewards error:', error);
        sendError(ws, error.message);
    } finally {
        client.release();
    }
}
async function handleAddCurrency(ws, data) {
    const requiredFields = ['player_id', 'money', 'donat_money'];
    if (!isValidMessage(data, requiredFields)) {
        return sendError(ws, 'Missing required fields: player_id, money, donat_money');
    }

    const client = await shooterPool.connect();
    try {
        await client.query('BEGIN');

        // 1. Обновляем валюту игрока
        const updateResult = await client.query(
            `UPDATE players SET 
                money = money + $1,
                donat_money = donat_money + $2
             WHERE player_id = $3
             RETURNING money, donat_money`,
            [data.money, data.donat_money, data.player_id]
        );

        if (updateResult.rowCount === 0) {
            throw new Error('Player not found');
        }

        await client.query('COMMIT');

        // 2. Отправляем обновленные данные
        ws.send(JSON.stringify({
            action: 'add_currency_response',
            success: true,
            money: updateResult.rows[0].money,
            donat_money: updateResult.rows[0].donat_money
        }));

    } catch (error) {
        await client.query('ROLLBACK');
        console.error('Add currency error:', error);
        sendError(ws, error.message);
    } finally {
        client.release();
    }
}
async function handleSpendHeroCards(ws, data) {
    if (!isValidMessage(data, ['player_id', 'cards_to_spend'])) {
        return sendError(ws, 'Missing player_id or cards_to_spend');
    }

    const client = await shooterPool.connect();
    try {
        await client.query('BEGIN');
        
        // 1. Check if player has enough cards
        const checkResult = await client.query(
            'SELECT hero_card FROM players WHERE player_id = $1 FOR UPDATE',
            [data.player_id]
        );
        
        if (checkResult.rows.length === 0) {
            throw new Error('Player not found');
        }
        
        const currentCards = checkResult.rows[0].hero_card || {};
        const cardsToSpend = data.cards_to_spend;
        
        // 2. Validate card counts
        for (const [heroId, count] of Object.entries(cardsToSpend)) {
            const currentCount = currentCards[heroId] || 0;
            if (currentCount < count) {
                throw new Error(`Not enough cards for hero ${heroId}`);
            }
        }
        
        // 3. Update card counts
        const updatedCards = {...currentCards};
        for (const [heroId, count] of Object.entries(cardsToSpend)) {
            updatedCards[heroId] = (updatedCards[heroId] || 0) - count;
            if (updatedCards[heroId] <= 0) {
                delete updatedCards[heroId];
            }
        }
        
        // 4. Save updated cards
        await client.query(
            'UPDATE players SET hero_card = $1 WHERE player_id = $2',
            [updatedCards, data.player_id]
        );
        
        await client.query('COMMIT');
        
        ws.send(JSON.stringify({
            action: 'spend_hero_cards_response',
            success: true,
            updated_cards: updatedCards
        }));
        
    } catch (error) {
        await client.query('ROLLBACK');
        console.error('Error spending hero cards:', error);
        sendError(ws, error.message);
    } finally {
        client.release();
    }
}

module.exports = {
    handleClaimRewards,
    handleAddCurrency,
    handleSpendHeroCards
};