const { shooterPool } = require('../config/db');

// Создание клана
async function handleCreateClan(ws, data) {
    const requiredFields = ['clan_name', 'leader_id', 'leader_name'];
    if (!isValidMessage(data, requiredFields)) {
        sendError(ws, 'Missing required fields');
        return;
    }

    const client = await shooterPool.connect();
    try {
        await client.query('BEGIN');
        
        // 1. Проверка существования клана
        const clanCheck = await client.query(
            'SELECT 1 FROM clans WHERE LOWER(clan_name) = LOWER($1)',
            [data.clan_name]
        );
        if (clanCheck.rows.length > 0) {
            throw new Error('Clan name already exists');
        }

        // 2. Получаем числовой ID игрока по его player_id (например "27-89804")
        const playerQuery = await client.query(
            'SELECT id FROM players WHERE player_id = $1',
            [data.leader_id]
        );
        
        if (playerQuery.rows.length === 0) {
            throw new Error('Leader not found');
        }
        
        const leaderId = playerQuery.rows[0].id;

        // 3. Проверяем, что игрок не состоит в другом клане
        const clanMemberCheck = await client.query(
            'SELECT 1 FROM clan_members WHERE player_id = $1',
            [leaderId]
        );
        
        if (clanMemberCheck.rows.length > 0) {
            throw new Error('Leader already in another clan');
        }

        // 4. Создание клана
        const clanResult = await client.query(
            `INSERT INTO clans 
             (clan_name, leader_id, leader_name, need_rating, is_open)
             VALUES ($1, $2, $3, $4, $5)
             RETURNING clan_id, clan_name`,
            [
                data.clan_name,
                leaderId, // Используем числовой ID из таблицы players
                data.leader_name,
                data.need_rating || 0,
                data.is_open !== false
            ]
        );
        
        const clanId = clanResult.rows[0].clan_id;
        const clanName = clanResult.rows[0].clan_name;

        // 5. Добавление лидера в clan_members
        await client.query(
            `INSERT INTO clan_members 
             (clan_id, player_name, player_id, is_leader)
             VALUES ($1, $2, $3, true)`,
            [clanId, data.leader_name, leaderId]
        );

        // 6. Обновление информации игрока
        await client.query(
            'UPDATE players SET clan_name = $1 WHERE id = $2',
            [clanName, leaderId]
        );
        
        await client.query('COMMIT');
        
        ws.send(JSON.stringify({
            action: 'create_clan_response',
            success: true,
            clan_id: clanId,
            clan_name: clanName,
            leader_id: data.leader_id, // Возвращаем оригинальный player_id
            leader_name: data.leader_name
        }));

    } catch (error) {
        await client.query('ROLLBACK');
        console.error('Clan creation error:', error);
        sendError(ws, error.message);
    } finally {
        client.release();
    }
}
// Вступление в клан
async function handleJoinClan(ws, data) {
    const requiredFields = ['clan_id', 'player_id'];
    if (!isValidMessage(data, requiredFields)) {
        return sendError(ws, `Missing required fields: ${requiredFields.join(', ')}`);
    }

    const client = await shooterPool.connect();
    try {
        await client.query('BEGIN');

        // 1. Получаем полные данные клана
        const clanCheck = await client.query(
            `SELECT 
                clan_id,
                clan_name,
                is_open,
                need_rating,
                max_players,
                player_count 
             FROM clans 
             WHERE clan_id = $1
             FOR UPDATE`,
            [data.clan_id]
        );
        
        if (clanCheck.rows.length === 0) {
            throw new Error('Clan not found');
        }
        const clan = clanCheck.rows[0];

        // 2. Получаем данные игрока, включая внутренний id
        const playerCheck = await client.query(
            `SELECT 
                id,
                player_name,
                rating,
                clan_name 
             FROM players 
             WHERE player_id = $1
             FOR UPDATE`,
            [data.player_id]
        );

        if (playerCheck.rows.length === 0) {
            throw new Error('Player not found');
        }
        const player = playerCheck.rows[0];

        // 3. Проверки условий вступления
        if (player.clan_name) throw new Error('Player already in another clan');
        if (!clan.is_open) throw new Error('Clan is closed for new members');
        if (player.rating < clan.need_rating) {
            throw new Error(`Player rating too low (need ${clan.need_rating})`);
        }
        if (clan.player_count >= clan.max_players) {
            throw new Error('Clan is full');
        }

        // 4. Добавляем игрока в клан (используем внутренний id из таблицы players)
        await client.query(
            `INSERT INTO clan_members 
             (clan_id, player_name, player_id, is_leader) 
             VALUES ($1, $2, $3, false)`,
            [data.clan_id, player.player_name, player.id] // Используем player.id вместо data.player_id
        );

        // // 5. Обновляем счетчик игроков в клане
        // await client.query(
        //     'UPDATE clans SET player_count = player_count + 1 WHERE clan_id = $1',
        //     [data.clan_id]
        // );

        // 6. Обновляем клан игрока
        await client.query(
            'UPDATE players SET clan_name = $1 WHERE id = $2',
            [clan.clan_name, player.id]
        );

        await client.query('COMMIT');

        // 7. Формируем ответ
        const response = {
            action: 'join_clan_response',
            success: true,
            clan_id: clan.clan_id,
            clan_name: clan.clan_name,
            player_count: clan.player_count,
            player_id: player.id, // Возвращаем внутренний id игрока
            player_name: player.player_name
        };

        ws.send(JSON.stringify(response));

    } catch (error) {
        await client.query('ROLLBACK');
        console.error('Join clan error:', error);
        sendError(ws, error.message);
    } finally {
        client.release();
    }
}
// Обработчик для обычного выхода из клана
async function handleLeaveClan(ws, data) {
    const requiredFields = ['player_id'];
    if (!isValidMessage(data, requiredFields)) {
        return sendError(ws, 'Missing required field: player_id');
    }

    const client = await shooterPool.connect();
    try {
        await client.query('BEGIN');

        // 1. Получаем внутренний ID игрока
        const playerRes = await client.query(
            'SELECT id FROM players WHERE player_id = $1',
            [data.player_id]
        );
        
        if (playerRes.rows.length === 0) {
            throw new Error('Player not found');
        }
        const playerId = playerRes.rows[0].id;

        // 2. Получаем данные клана
        const clanRes = await client.query(
            `SELECT cm.clan_id, cm.is_leader, c.clan_name 
             FROM clan_members cm
             JOIN clans c ON cm.clan_id = c.clan_id
             WHERE cm.player_id = $1 FOR UPDATE`,
            [playerId]
        );
        
        if (clanRes.rows.length === 0) {
            throw new Error('Player not in any clan');
        }
        const clanId = clanRes.rows[0].clan_id;
        const isLeader = clanRes.rows[0].is_leader;
        const clanName = clanRes.rows[0].clan_name;

        // 3. Удаляем игрока из клана (триггер автоматически обновит clan_points)
        await client.query(
            'DELETE FROM clan_members WHERE player_id = $1',
            [playerId]
        );

        // 4. Обновляем запись игрока
        await client.query(
            'UPDATE players SET clan_name = NULL, clan_points = 0 WHERE id = $1',
            [playerId]
        );

        // 5. Обработка лидера
        let clanDeleted = false;
        if (isLeader) {
            const newLeaderRes = await client.query(
                `SELECT cm.player_id, p.player_name 
                 FROM clan_members cm
                 JOIN players p ON cm.player_id = p.id
                 WHERE cm.clan_id = $1 
                 ORDER BY p.rating DESC 
                 LIMIT 1 FOR UPDATE`,
                [clanId]
            );

            if (newLeaderRes.rows.length > 0) {
                const newLeader = newLeaderRes.rows[0];
                await client.query(
                    'UPDATE clans SET leader_id = $1, leader_name = $2 WHERE clan_id = $3',
                    [newLeader.player_id, newLeader.player_name, clanId]
                );
                await client.query(
                    'UPDATE clan_members SET is_leader = true WHERE player_id = $1 AND clan_id = $2',
                    [newLeader.player_id, clanId]
                );
            } else {
                await client.query('DELETE FROM clans WHERE clan_id = $1', [clanId]);
                clanDeleted = true;
            }
        }

        await client.query('COMMIT');

        ws.send(JSON.stringify({
            action: 'leave_clan_response',
            success: true,
            player_id: data.player_id,
            was_leader: isLeader,
            clan_deleted: clanDeleted,
            clan_name: clanName
        }));

    } catch (error) {
        await client.query('ROLLBACK');
        console.error('Leave clan error:', error);
        sendError(ws, error.message);
    } finally {
        client.release();
    }
}
// Обработчик для передачи лидерства
async function handleTransferLeadership(ws, data) {
    const requiredFields = ['current_leader_id', 'new_leader_id', 'clan_id'];
    if (!isValidMessage(data, requiredFields)) {
        return sendError(ws, 'Missing required fields');
    }

    const client = await shooterPool.connect();
    try {
        await client.query('BEGIN');

        // 1. Проверяем, что текущий пользователь действительно лидер
        const leaderCheck = await client.query(
            'SELECT 1 FROM clans WHERE leader_id = $1 AND clan_id = $2',
            [data.current_leader_id, data.clan_id]
        );
        
        if (leaderCheck.rows.length === 0) {
            throw new Error('Only clan leader can transfer leadership');
        }

        // 2. Проверяем, что новый лидер состоит в клане
        const memberCheck = await client.query(
            'SELECT 1 FROM clan_members WHERE player_id = $1 AND clan_id = $2',
            [data.new_leader_id, data.clan_id]
        );
        
        if (memberCheck.rows.length === 0) {
            throw new Error('New leader must be a clan member');
        }

        // 3. Получаем имя нового лидера
        const nameRes = await client.query(
            'SELECT player_name FROM players WHERE player_id = $1',
            [data.new_leader_id]
        );
        const newLeaderName = nameRes.rows[0].player_name;

        // 4. Обновляем лидера в клане
        await client.query(`
            UPDATE clans SET 
                leader_id = $1,
                leader_name = $2 
            WHERE clan_id = $3`,
            [data.new_leader_id, newLeaderName, data.clan_id]);
        
        // 5. Обновляем флаги лидерства у участников
        await client.query(`
            UPDATE clan_members SET 
                is_leader = (player_id = $1)
            WHERE clan_id = $2`,
            [data.new_leader_id, data.clan_id]);

        await client.query('COMMIT');

        ws.send(JSON.stringify({
            action: 'transfer_leadership_response',
            success: true,
            clan_id: data.clan_id,
            new_leader_id: data.new_leader_id,
            new_leader_name: newLeaderName
        }));

    } catch (error) {
        await client.query('ROLLBACK');
        console.error('Transfer leadership error:', error);
        sendError(ws, error.message);
    } finally {
        client.release();
    }
}
// Обработчик получения списка кланов
async function handleGetAllClans(ws) {
    const client = await shooterPool.connect();
    try {
        // Получаем список кланов с уникальными местами
        const result = await client.query(
            `WITH ranked_clans AS (
                SELECT 
                    c.clan_id,
                    c.clan_name,
                    c.leader_name,
                    c.need_rating,
                    c.is_open,
                    c.clan_points,
                    c.clan_level,
                    c.max_players,
                    COUNT(cm.player_name) as player_count,
                    SUM(p.clan_points) as members_points_sum,
                    ROW_NUMBER() OVER (ORDER BY c.clan_points DESC, c.clan_id) as place
                FROM clans c
                LEFT JOIN clan_members cm ON c.clan_id = cm.clan_id
                LEFT JOIN players p ON cm.player_id = p.id
                GROUP BY c.clan_id
            )
            SELECT * FROM ranked_clans
            ORDER BY place`
        );
        
        // Формируем ответ
        const clans = result.rows.map(clan => ({
            clan_id: clan.clan_id,
            clan_name: clan.clan_name,
            leader_name: clan.leader_name,
            need_rating: clan.need_rating,
            is_open: clan.is_open,
            clan_points: clan.clan_points,
            clan_level: clan.clan_level,
            player_count: clan.player_count,
            max_players: clan.max_players,
            points_valid: clan.clan_points === clan.members_points_sum,
            place: clan.place  // Уникальное место для каждого клана
        }));
        
        ws.send(JSON.stringify({
            action: 'clan_list_response',
            clans: clans,
            server_time: new Date().toISOString()
        }));
        
    } catch (error) {
        console.error('Error getting clans:', error);
        sendError(ws, 'Failed to get clan list: ' + error.message);
    } finally {
        client.release();
    }
}
// Получение топ 10 кланов и клана в котом мы находимся
async function handleGetClanInfoWithTop(ws, data) {
    if (!data.player_id && !data.clan_id) {
        return sendError(ws, 'Provide either player_id or clan_id');
    }

    const client = await shooterPool.connect();
    try {
        const query = `
            WITH ranked_clans AS (
                SELECT 
                    c.clan_id, c.clan_name, c.leader_name, c.leader_id,
                    c.need_rating, c.is_open, c.clan_points, c.clan_level,
                    c.max_players, c.player_count,
                    ROW_NUMBER() OVER (ORDER BY c.clan_points DESC, c.clan_id) as place
                FROM clans c
            ),
            current_clan AS (
                SELECT clan_id 
                FROM clan_members 
                WHERE player_id = $1 OR clan_id = $2
                LIMIT 1
            )
            SELECT 
                rc.*,
                CASE WHEN EXISTS (SELECT 1 FROM current_clan WHERE clan_id = rc.clan_id) 
                     THEN true ELSE false END as is_current_clan
            FROM ranked_clans rc
            WHERE 
                rc.place <= 10 OR
                EXISTS (SELECT 1 FROM current_clan WHERE clan_id = rc.clan_id)
            ORDER BY rc.place`;

        const result = await client.query(query, [
            data.player_id || null, 
            data.clan_id || null
        ]);

        const allClans = result.rows;
        const currentClan = allClans.find(c => c.is_current_clan) || null;
        
        // Формируем топ-10, гарантированно включая текущий клан если он в топе
        let topClans = allClans.filter(c => c.place <= 10);
        
        // Если текущий клан не в топе, заменяем последний в топе на текущий клан
        if (currentClan && currentClan.place > 10 && topClans.length >= 10) {
            topClans[9] = currentClan; // Заменяем 10-й элемент
        }

        const response = {
            action: 'clan_info_with_top_response',
            success: true,
            top_clans: topClans,
            current_clan: currentClan
        };

        ws.send(JSON.stringify(response));

    } catch (error) {
        console.error('Error in handleGetClanInfoWithTop:', error);
        ws.send(JSON.stringify({
            action: 'clan_info_with_top_response',
            success: false,
            error: error.message || 'Unknown error'
        }));
    } finally {
        client.release();
    }
}

async function handleGetClanInfo(ws, data) {
    if (!data.clan_id && !data.clan_name) {
        return sendError(ws, 'Provide either clan_id or clan_name');
    }

    const client = await shooterPool.connect();
    try {
        await client.query('BEGIN');

        // 1. Получаем расширенную информацию о клане (включая clan_level)
        const clanQuery = data.clan_id 
            ? `SELECT 
                  c.clan_id, c.clan_name, c.leader_id, c.leader_name,
                  c.need_rating, c.is_open, c.player_count, 
                  c.max_players, c.clan_points, c.clan_level,
                  SUM(p.clan_points) as calculated_points
               FROM clans c
               LEFT JOIN clan_members cm ON c.clan_id = cm.clan_id
               LEFT JOIN players p ON cm.player_id = p.id
               WHERE c.clan_id = $1
               GROUP BY c.clan_id`
            : `SELECT 
                  c.clan_id, c.clan_name, c.leader_id, c.leader_name,
                  c.need_rating, c.is_open, c.player_count, 
                  c.max_players, c.clan_points, c.clan_level,
                  SUM(p.clan_points) as calculated_points
               FROM clans c
               LEFT JOIN clan_members cm ON c.clan_id = cm.clan_id
               LEFT JOIN players p ON cm.player_id = p.id
               WHERE c.clan_name = $1
               GROUP BY c.clan_id`;
        
        const clanParam = data.clan_id || data.clan_name;
        const clanResult = await client.query(clanQuery, [clanParam]);

        if (clanResult.rows.length === 0) {
            throw new Error('Clan not found');
        }
        const clan = clanResult.rows[0];

        // Проверка синхронизации очков
        const pointsValid = clan.clan_points === clan.calculated_points;

        // 2. Получаем рейтинг лидера
        const leaderRatingRes = await client.query(
            `SELECT rating, best_rating 
             FROM players 
             WHERE id = $1`,
            [clan.leader_id]
        );
        const leaderRating = leaderRatingRes.rows[0]?.rating || 0;
        const leaderBestRating = leaderRatingRes.rows[0]?.best_rating || 0;

        // 3. Получаем участников клана с их статистикой
        const membersRes = await client.query(
            `SELECT 
                cm.player_id,
                cm.player_name,
                cm.is_leader,
                p.rating,
                p.best_rating,
                p.clan_points,
                p.overral_kill,
                p.match_count,
                p.win_count
             FROM clan_members cm
             JOIN players p ON cm.player_id = p.id
             WHERE cm.clan_id = $1
             ORDER BY cm.is_leader DESC, p.rating DESC`,
            [clan.clan_id]
        );

        // 4. Рассчитываем прогресс до следующего уровня
        const nextLevelThreshold = getNextLevelThreshold(clan.clan_level);
        const levelProgress = nextLevelThreshold 
            ? Math.min(100, Math.round((clan.clan_points / nextLevelThreshold) * 100))
            : 100;

        // 5. Получаем место клана в общем рейтинге
        const placeRes = await client.query(
            `SELECT place FROM (
                SELECT 
                    clan_id, 
                    RANK() OVER (ORDER BY clan_points DESC) as place
                FROM clans
            ) ranked_clans
            WHERE clan_id = $1`,
            [clan.clan_id]
        );
        const place = placeRes.rows[0]?.place || 0;

        await client.query('COMMIT');

        // 6. Формируем расширенный ответ с информацией об уровне
        const response = {
            action: 'get_clan_info_response',
            success: true,
            clan: {
                id: clan.clan_id,
                name: clan.clan_name,
                leader: {
                    id: clan.leader_id,
                    name: clan.leader_name,
                    rating: leaderRating,
                    best_rating: leaderBestRating
                },
                stats: {
                    place: place,
                    points: clan.clan_points,
                    player_count: clan.player_count,
                    max_players: clan.max_players,
                    current_level: clan.clan_level,
                    next_level_progress: levelProgress,
                    need_rating: clan.need_rating,
                    is_open: clan.is_open,
                    points_valid: pointsValid,
                    points_breakdown: {
                        current: clan.clan_points,
                        calculated: clan.calculated_points,
                        difference: clan.clan_points - (clan.calculated_points || 0)
                    }
                }
            },
            members: membersRes.rows.map(member => ({
                id: member.player_id,
                name: member.player_name,
                is_leader: member.is_leader,
                stats: {
                    rating: member.rating,
                    best_rating: member.best_rating,
                    clan_points: member.clan_points,
                    kills: member.overral_kill,
                    matches: member.match_count,
                    wins: member.win_count,
                    contribution_percent: clan.clan_points > 0 
                        ? Math.round((member.clan_points / clan.clan_points) * 100)
                        : 0
                }
            }))
        };

        ws.send(JSON.stringify(response));

    } catch (error) {
        await client.query('ROLLBACK');
        console.error('Get clan info error:', error);
        sendError(ws, error.message);
    } finally {
        client.release();
    }
}
// Вспомогательная функция для определения порога следующего уровня
function getNextLevelThreshold(currentLevel) {
    const thresholds = {
        0: 150,
        1: 500,
        2: 2000,
        3: 5000,
        4: 10000,
        5: 20000,
        6: 35000,
        7: 60000,
        8: 100000,
        9: 150000,
        10: null // Максимальный уровень
    };
    return thresholds[currentLevel] || null;
}

async function handleSearchClans(ws, data) {
    const requiredFields = ['search_term'];
    if (!isValidMessage(data, requiredFields)) {
        return sendError(ws, 'Missing search term');
    }

    const limit = data.limit || 20;
    const offset = data.offset || 0;
    const searchTerm = data.search_term.trim();

    if (searchTerm.length < 2) {
        return sendError(ws, 'Search term too short (min 2 characters)');
    }

    const client = await shooterPool.connect();
    try {
        const result = await client.query(
            `SELECT 
                c.clan_id,
                c.clan_name,
                c.leader_name,
                c.need_rating,
                c.is_open,
                c.clan_points,
                c.clan_level,
                COUNT(cm.player_name) as player_count,
                c.max_players,
                SUM(p.clan_points) as members_points_sum
             FROM clans c
             LEFT JOIN clan_members cm ON c.clan_id = cm.clan_id
             LEFT JOIN players p ON cm.player_id = p.id
             WHERE c.clan_name ILIKE $1
             GROUP BY c.clan_id, c.max_players, c.clan_level
             ORDER BY 
                 CASE 
                     WHEN c.clan_name ILIKE $2 THEN 0 -- Точное совпадение
                     WHEN c.clan_name ILIKE $3 THEN 1 -- Начинается с
                     ELSE 2 -- Содержит
                 END,
                 c.clan_points DESC
             LIMIT $4 OFFSET $5`,
            [
                `%${searchTerm}%`,
                `${searchTerm}`,
                `${searchTerm}%`,
                limit,
                offset
            ]
        );

        const clans = result.rows.map(clan => ({
            clan_id: clan.clan_id,
            clan_name: clan.clan_name,
            leader_name: clan.leader_name,
            need_rating: clan.need_rating,
            is_open: clan.is_open,
            player_count: clan.player_count,
            max_players: clan.max_players,
            clan_points: clan.clan_points,
            clan_level: clan.clan_level,
            points_valid: clan.clan_points === clan.members_points_sum
        }));

        ws.send(JSON.stringify({
            action: 'clan_search_results',
            success: true,
            clans: clans,
            count: clans.length,
            total: result.rowCount,
        }));

    } catch (error) {
        console.error('Clan search error:', error);
        sendError(ws, 'Search failed: ' + error.message);
    } finally {
        client.release();
    }
}

module.exports = {
    handleCreateClan,
    handleJoinClan,
    handleLeaveClan,
    handleTransferLeadership,
    handleGetAllClans,
    handleGetClanInfoWithTop,
    handleGetClanInfo,
    handleSearchClans
};