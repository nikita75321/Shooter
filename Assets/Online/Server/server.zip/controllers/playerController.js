import { shooterPool } from '../config/db';

//Регистрация нового игрока
async function handleRegisterPlayer(ws, data) {
    const client = await shooterPool.connect();
    try {
        await client.query('BEGIN');
        
        // Регистрируем нового игрока
        const insertResult = await client.query(
            `INSERT INTO players 
             (player_name, platform, open_characters, love_hero) 
             VALUES ($1, $2, $3, $4)
             RETURNING id`,
            [
                data.player_name,
                data.platform || 'неизвестно',
                data.open_characters || '{}',
                data.love_hero || 'нет'
            ]
        );
        
        // Генерируем player_id в формате "id-рандомное число"
        const playerId = `${insertResult.rows[0].id}-${Math.floor(10000 + Math.random() * 90000)}`;
        
        // Обновляем запись с player_id
        await client.query(
            'UPDATE players SET player_id = $1 WHERE id = $2',
            [playerId, insertResult.rows[0].id]
        );
        
        // Получаем полные данные игрока
        const result = await client.query(
            'SELECT id, player_name, player_id FROM players WHERE id = $1',
            [insertResult.rows[0].id]
        );
        
        await client.query('COMMIT');
        
        ws.send(JSON.stringify({
            action: 'register_player_response',
            success: true,
            id: result.rows[0].id,
            player_name: result.rows[0].player_name,
            player_id: result.rows[0].player_id
        }));

    } catch (error) {
        await client.query('ROLLBACK');
        console.error('Register player error:', error);
        sendError(ws, error.message);
    } finally {
        client.release();
    }
}
// Создание/обновление игрока
async function handlePlayerConnect(ws, data) {
    if (!isValidMessage(data, ['player_id', 'player_name'])) {
        throw new Error('Missing required fields: player_id or player_name');
    }

    const client = await shooterPool.connect();
    try {
        await client.query('BEGIN');
        
        // Проверяем существование игрока
        const checkResult = await client.query(
            'SELECT 1 FROM players WHERE player_id = $1',
            [data.player_id]
        );
        
        if (checkResult.rows.length > 0) {
            // Обновляем последнее время онлайн
            await client.query(
                'UPDATE players SET last_online = NOW(), player_name = $1 WHERE player_id = $2',
                [data.player_name, data.player_id]
            );
        } else {
            // Создаем нового игрока
            await client.query(
                'INSERT INTO players (player_id, player_name) VALUES ($1, $2)',
                [data.player_id, data.player_name]
            );
        }
        
        await client.query('COMMIT');
    } catch (error) {
        await client.query('ROLLBACK');
        console.error('Error in handlePlayerConnect:', error);
    } finally {
        client.release();
    }
}
// Получение информации об игроке
async function handleGetPlayerInfo(ws, data) {
    if (!isValidMessage(data, ['player_id'])) {
        throw new Error('Missing player_id');
    }

    const client = await shooterPool.connect();
    try {
        const result = await client.query(
            'SELECT player_id, player_name, rating FROM players WHERE player_id = $1',
            [data.player_id]
        );
        
        if (result.rows.length > 0) {
            ws.send(JSON.stringify({
                action: 'get_player_info_response',
                player: result.rows[0]
            }));
        } else {
            sendError(ws, 'Player not found');
        }
    } catch (error) {
        console.error('Error in handleGetPlayerInfo:', error);
        sendError(ws, 'Failed to get player info');
    } finally {
        client.release();
    }
}
// Обновление рейтинга игрока
async function handleUpdatePlayerRating(ws, data) {
    if (!isValidMessage(data, ['player_id', 'rating_change'])) {
        throw new Error('Missing player_id or rating_change');
    }

    const client = await shooterPool.connect();
    try {
        await client.query('BEGIN');
        
        await client.query(
            'UPDATE players SET rating = rating + $1 WHERE player_id = $2',
            [data.rating_change, data.player_id]
        );
        
        await client.query('COMMIT');
        
        ws.send(JSON.stringify({
            action: 'update_rating_response',
            success: true
        }));
    } catch (error) {
        await client.query('ROLLBACK');
        console.error('Error in handleUpdatePlayerRating:', error);
        sendError(ws, 'Failed to update player rating');
    } finally {
        client.release();
    }
}
// Проверка доступности имени
async function handleCheckName(ws, data) {
    if (!isValidMessage(data, ['player_name'])) {
        throw new Error('Missing player_name');
    }

    const client = await shooterPool.connect();
    try {
        const result = await client.query(
            'SELECT 1 FROM players WHERE player_name = $1',
            [data.player_name]
        );
        
        ws.send(JSON.stringify({
            action: 'check_name_response',
            available: result.rows.length === 0,
            requested_name: data.player_name
        }));
    } catch (error) {
        console.error('Error in handleCheckName:', error);
        sendError(ws, 'Failed to check name availability');
    } finally {
        client.release();
    }
}
// Обновление имени игрока
async function handleUpdatePlayerName(ws, data) {
    if (!isValidMessage(data, ['player_id', 'new_name'])) {
        return sendError(ws, 'Missing player_id or new_name');
    }

    const client = await shooterPool.connect();
    try {
        await client.query('BEGIN');
        
        // 1. Получаем внутренний ID игрока по его player_id (строке)
        const playerRes = await client.query(
            'SELECT id FROM players WHERE player_id = $1',
            [data.player_id]
        );
        
        if (playerRes.rows.length === 0) {
            throw new Error('Player not found');
        }
        const playerId = playerRes.rows[0].id;

        // 2. Проверка на существование имени (исключая текущего игрока)
        const nameCheck = await client.query(
            'SELECT 1 FROM players WHERE player_name = $1 AND player_id != $2',
            [data.new_name, data.player_id]
        );
        
        if (nameCheck.rows.length > 0) {
            throw new Error('Player name already taken');
        }

        // 3. Обновление имени в таблице players (по строковому player_id)
        await client.query(
            'UPDATE players SET player_name = $1 WHERE player_id = $2',
            [data.new_name, data.player_id]
        );
        
        // 4. Обновление имени в clan_members (по внутреннему числовому ID)
        await client.query(
            'UPDATE clan_members SET player_name = $1 WHERE player_id = $2',
            [data.new_name, playerId]
        );
        
        await client.query('COMMIT');
        
        ws.send(JSON.stringify({
            action: 'update_name_response',
            success: true,
            new_name: data.new_name
        }));

    } catch (error) {
        await client.query('ROLLBACK');
        console.error('Error updating player name:', error);
        sendError(ws, error.message);
    } finally {
        client.release();
    }
}
// Обновление рейтинга
async function handleUpdateRating(ws, data) {
    if (!isValidMessage(data, ['player_name', 'rating_change'])) {
        throw new Error('Missing player_name or rating_change');
    }

    const client = await shooterPool.connect();
    try {
        await client.query('BEGIN');
        
        await client.query(
            'UPDATE players SET rating = rating + $1 WHERE player_name = $2',
            [data.rating_change, data.player_name]
        );
        
        await client.query('COMMIT');
        
        ws.send(JSON.stringify({
            action: 'update_rating_response',
            success: true
        }));
    } catch (error) {
        await client.query('ROLLBACK');
        console.error('Error in handleUpdateRating:', error);
        sendError(ws, error.message);
    } finally {
        client.release();
    }
}
//Получение данных игрока
async function handleGetPlayerData(ws, data) {
    const requiredFields = ['player_id'];
    if (!isValidMessage(data, requiredFields)) {
        return sendError(ws, 'Missing required fields: player_id');
    }

    const client = await shooterPool.connect();
    try {
        // 1. Get basic player data
        const playerResult = await client.query(
            `SELECT 
                p.player_id,
                p.player_name,
                p.rating,
                p.best_rating,
                p.money,
                p.donat_money,
                p.clan_name,
                p.clan_points,
                p.platform,
                p.open_characters,
                p.love_hero,
                p.overral_kill,
                p.match_count,
                p.win_count,
                p.revive_count,
                p.max_damage,
                p.shoot_count,
                p.friends_reward,
                p.hero_card,
                p.hero_match,
                p.hero_levels,
                c.clan_id
             FROM players p
             LEFT JOIN clans c ON p.clan_name = c.clan_name
             WHERE p.player_id = $1`,
            [data.player_id]
        );

        if (playerResult.rows.length === 0) {
            throw new Error('Player not found');
        }

        const playerData = playerResult.rows[0];

        // 2. Prepare clan data
        let clanData = null;
        if (playerData.clan_name) {
            clanData = {
                id: playerData.clan_id,
                name: playerData.clan_name,
                points: playerData.clan_points
            };
        }

        // 3. Prepare open_characters data
        let openCharacters = {};
        try {
            if (playerData.open_characters) {
                openCharacters = playerData.open_characters;
            }
        } catch (e) {
            console.error('Error parsing open_characters:', e);
            openCharacters = {"Kayel": [1, 0, 0, 0, 0, 0, 0, 0, 0]};
        }

        // 4. Send response
        ws.send(JSON.stringify({
            action: 'get_player_data_response',
            success: true,
            player: {
                id: playerData.player_id,
                name: playerData.player_name,
                rating: playerData.rating,
                bestRating: playerData.best_rating,
                money: playerData.money,
                donatMoney: playerData.donat_money,
                clan: clanData, // Теперь содержит clan_id
                stats: {
                    overral_kill: playerData.overral_kill,
                    matches: playerData.match_count,
                    win_count: playerData.win_count,
                    lose_count: playerData.match_count - playerData.win_count,
                    revive_count: playerData.revive_count,
                    max_damage: playerData.max_damage,
                    shoot_count: playerData.shoot_count
                },
                characters: openCharacters,
                favoriteHero: playerData.love_hero,
                platform: playerData.platform,
                friendsReward: playerData.friends_reward,
                hero_card: playerData.hero_card,
                hero_match: playerData.hero_match,
                hero_levels: playerData.hero_levels
            }
        }));

    } catch (error) {
        console.error('Get player data error:', error);
        sendError(ws, error.message);
    } finally {
        client.release();
    }
}

module.exports = {
    handleRegisterPlayer,
    handlePlayerConnect,
    handleGetPlayerInfo,
    handleUpdatePlayerRating,
    handleCheckName,
    handleUpdatePlayerName,
    handleUpdateRating,
    handleGetPlayerData
};