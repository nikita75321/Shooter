const { shooterPool } = require('../config/db');

async function handleUpdateHeroStats(ws, data) {
    const requiredFields = ['player_id', 'hero_id', 'matches_to_add', 'hero_match'];
    if (!isValidMessage(data, requiredFields)) {
        return sendError(ws, 'Missing required fields: player_id, hero_id, matches_to_add, hero_match');
    }

    const client = await shooterPool.connect();
    try {
        await client.query('BEGIN');

        await client.query(
            `UPDATE players 
             SET hero_match = $1::integer[]
             WHERE player_id = $2`,
            [data.hero_match, data.player_id]
        );

        if (data.is_favorite) {
            await client.query(
                `UPDATE players 
                 SET love_hero = $1
                 WHERE player_id = $2`,
                [data.hero_id.toString(), data.player_id]
            );
        }

        await client.query('COMMIT');

        const result = await client.query(
            `SELECT hero_match, love_hero 
             FROM players 
             WHERE player_id = $1`,
            [data.player_id]
        );

        ws.send(JSON.stringify({
            action: 'update_hero_stats_response',
            success: true,
            hero_match: result.rows[0].hero_match,
            favorite_hero: result.rows[0].love_hero
        }));

    } catch (error) {
        await client.query('ROLLBACK');
        console.error('Update hero stats error:', error);
        sendError(ws, error.message);
    } finally {
        client.release();
    }
}
async function handleUpdateFavoriteHero(ws, data) {
    const client = await pool.connect();
    try {
        await client.query(
            'UPDATE players SET favorite_hero = $1 WHERE player_id = $2',
            [data.favorite_hero, data.player_id]
        );
    } catch (error) {
        console.error('Favorite hero update error:', error);
        sendError(ws, 'Failed to update favorite hero');
    } finally {
        client.release();
    }
}
async function handleGetHeroLevels(ws, data) {
    if (!isValidMessage(data, ['player_id'])) {
        return sendError(ws, 'Missing player_id');
    }

    const client = await shooterPool.connect();
    try {
        const result = await client.query(
            'SELECT hero_levels FROM players WHERE player_id = $1',
            [data.player_id]
        );

        ws.send(JSON.stringify({
            action: 'hero_levels_response',
            hero_levels: result.rows[0]?.hero_levels || []
        }));

    } catch (error) {
        console.error('Error getting hero levels:', error);
        sendError(ws, 'Failed to get hero levels');
    } finally {
        client.release();
    }
}
async function handleUpdateHeroLevels(ws, data) {
    const requiredFields = ['player_id', 'hero_id', 'level', 'rank'];
    if (!isValidMessage(data, requiredFields)) {
        console.log('[ERROR] Missing required fields');
        return sendError(ws, 'Missing required fields');
    }

    // Validate data
    const heroId = parseInt(data.hero_id);
    const level = parseInt(data.level);
    const rank = parseInt(data.rank);
    
    if (isNaN(heroId) || heroId < 0 || heroId > 7) {
        console.log('[ERROR] Invalid hero_id:', data.hero_id);
        return sendError(ws, 'Invalid hero_id (must be 0-7)');
    }
    
    if (isNaN(level) || level < 1 || level > 50) {
        console.log('[ERROR] Invalid level:', data.level);
        return sendError(ws, 'Invalid level (must be 1-50)');
    }
    
    if (isNaN(rank) || rank < 1 || rank > 6) {
        console.log('[ERROR] Invalid rank:', data.rank);
        return sendError(ws, 'Invalid rank (must be 1-6)');
    }

    const client = await shooterPool.connect();
    try {
        await client.query('BEGIN');

        // Corrected query using array index syntax
        const result = await client.query(`
            UPDATE players 
            SET hero_levels = jsonb_set(
                hero_levels,
                ARRAY[$1::text],
                jsonb_build_object(
                    'level', $2::int,
                    'rank', $3::int
                ),
                true
            )
            WHERE player_id = $4
            RETURNING hero_levels
        `, [heroId.toString(), level, rank, data.player_id]);

        if (result.rowCount === 0) {
            throw new Error('Player not found');
        }

        await client.query('COMMIT');
        
        ws.send(JSON.stringify({
            action: 'update_hero_levels_response',
            success: true,
            hero_id: heroId,
            level: level,
            rank: rank,
            hero_levels: result.rows[0].hero_levels
        }));

    } catch (error) {
        await client.query('ROLLBACK');
        console.error('[ERROR] Update hero levels failed:', error.stack);
        
        let errorMsg = 'Failed to update hero levels';
        if (error.message.includes('invalid input syntax for type jsonb')) {
            errorMsg = 'Invalid hero levels data format';
        } else if (error.message.includes('array subscript out of range')) {
            errorMsg = 'Invalid hero_id (out of range)';
        } else if (error.message.includes('Player not found')) {
            errorMsg = 'Player not found';
        }
        
        sendError(ws, errorMsg);
    } finally {
        client.release();
    }
}

module.exports = {
    handleUpdateHeroStats,
    handleUpdateFavoriteHero,
    handleGetHeroLevels,
    handleUpdateHeroLevels
};