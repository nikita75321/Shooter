const https = require('https');
const fs = require('fs');
const express = require('express');
const { setupWebSocketServer } = require('./services/websocket');
const { initializeDatabase } = require('./config/db');
const { createClient } = require('redis');
const path = require('path');
const WebSocket = require('ws');

// SSL сертификаты
const sslOptions = {
    key: fs.readFileSync('/etc/letsencrypt/live/game.beatragdollsandbox.space/privkey.pem'),
    cert: fs.readFileSync('/etc/letsencrypt/live/game.beatragdollsandbox.space/fullchain.pem')
};

const app = express();
const server = https.createServer(sslOptions, app);
const port = process.env.PORT || 3000;

const heapdump = require('heapdump');

//Проверка памяти
setInterval(() => {
    try {
        const heapUsed = process.memoryUsage().heapUsed;
        if (heapUsed > 100 * 1024 * 1024) { // 100MB
            const filename = `/tmp/heapdump-${Date.now()}.heapsnapshot`;
            heapdump.writeSnapshot(filename, (err) => {
                if (err) {
                    console.error('Failed to write heapdump:', err);
                } else {
                    console.log(`Heapdump written to ${filename} (heap used: ${Math.round(heapUsed / (1024 * 1024))}MB)`);
                }
            });
        }
    } catch (err) {
        console.error('Error in memory monitor:', err);
    }
}, 60000); // Каждую минуту

//Статус панель
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.use((err, req, res, next) => {
    console.error('Detailed error:', err);
    res.status(500).send(`Error: ${err.message}`);
});

// Подключение к редису
const redisClient = createClient({
    url: 'redis://localhost:6379',
    socket: {
        reconnectStrategy: (retries) => {
            if (retries > 10) {
                console.log('Too many retries, exiting...');
                process.exit(1);
            }
            return Math.min(retries * 100, 5000);
        }
    }
});
redisClient.on('error', (err) => console.log('Redis Client Error', err));
//Сокет + подключение к серверу
let wss;
(async () => {
    await redisClient.connect();
    global.redisClient = redisClient;

    // Инициализация базы данных
    initializeDatabase();
    
    await  initializeRedisPubSub();
    
    // Запуск WebSocket сервера после подключения к Redis
    wss = setupWebSocketServer(server);
    global.wss = wss;
    // Запуск HTTP сервера
    server.listen(port, () => {
        console.log(`Server running on port ${port}`);
    });
})();

//позволяет перекидывать инфу между кластерами через редис
async function initializeRedisPubSub() {
    const subscriber = global.redisClient.duplicate();
    await subscriber.connect();
    
    await subscriber.unsubscribe();
    
    await subscriber.subscribe('websocket_messages', (message) => {
        //const { roomId, wsId, data } = JSON.parse(message); Подписывемся, что хотим передавать
        
        global.wss.clients.forEach((client) => {
          /*  if (client.id === wsId) {
                client.send(JSON.stringify(data));
            } ПЕРЕДАЕМ*/
        });
    });
}

// Graceful shutdown обработчики - то, что происходит при pm2 restart
const gracefulShutdown = () => {
    console.log('Завершение работы...');

    // Отправляем уведомление о перезагрузке всем клиентам
    wss.clients.forEach(client => {
        if (client.readyState === WebSocket.OPEN) {
            client.send(JSON.stringify({
                action: 'call',
                message: 'server_restart'
            }));
        }
    });

    // Закрываем WebSocket-сервер
    wss.clients.forEach(client => {
        if (client.readyState === WebSocket.OPEN) {
            client.close(1001, 'Server restarting'); // 1001 = "going away"
        }
    });

    // Даём время на закрытие соединений
    setTimeout(() => {
        wss.close(() => {
            server.close(() => {
                console.log('Сервер корректно остановлен');
                process.exit(0);
            });
        });
    }, 5000); // 5 секунд на завершение
};

process.on('SIGINT', gracefulShutdown);
process.on('SIGTERM', gracefulShutdown);